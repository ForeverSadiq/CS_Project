<?php
include 'db.php';
include 'logger.php';
//if ($_SERVER["REQUEST_METHOD"] == "POST") {
  //  $username = htmlspecialchars($_POST['username']);
   // $comment = htmlspecialchars($_POST['comment']);
    
  //  $stmt = $conn->prepare("INSERT INTO comments (username, comment) VALUES (?, ?)");
   // $stmt->bind_param("ss", $username, $comment);

//    $stmt->execute();
    
  //  header("Location: comment.php"); // or wherever you want to redirect after saving
   // exit();
    
//}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $comment = $_POST['comment'];

    if (preg_match("/<script|onerror|onload/i", $comment)) {
    logAttack("XSS", $_SERVER['REMOTE_ADDR'], "Username: $username, Comment: $comment");
}
    $stmt = $conn->prepare("INSERT INTO comments (username, comment) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $comment);

    $stmt->execute();
    $stmt->close();

   // 🔒 Redirect to avoid resubmission and output script execution
    header("Location: comment.php");
    exit();
    
}
?>
