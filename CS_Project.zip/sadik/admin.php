<?php
include 'db.php';

// Escape output function
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Delete functions
function delete_comment($conn, $id) {
    $stmt = $conn->prepare("DELETE FROM comments WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

function delete_contact($conn, $id) {
    $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

// Handle deletions via GET (Consider POST + CSRF for production)
if (isset($_GET['delete_comment'])) {
    $id = intval($_GET['delete_comment']);
    if ($id > 0) {
        delete_comment($conn, $id);
    }
    header("Location: admin.php");
    exit();
}

if (isset($_GET['delete_contact'])) {
    $id = intval($_GET['delete_contact']);
    if ($id > 0) {
        delete_contact($conn, $id);
    }
    header("Location: admin.php");
    exit();
}

// Handle new comment submission
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit_comment'])) {
    $username = trim($_POST['username']);
    $comment = trim($_POST['comment']);

    if ($username !== '' && $comment !== '') {
        $stmt = $conn->prepare("INSERT INTO comments (username, comment, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("ss", $username, $comment);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Panel - Cyber Security Test Site</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: #f9f9f9;
            color: #333;
            margin: 20px;
        }
        h1, h2, h3 {
            font-weight: 600;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background: #fff;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.9rem;
        }
        tbody tr:hover {
            background-color: #f1f7ff;
        }
        a.delete-btn {
            background-color: #dc3545;
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: background-color 0.2s ease-in-out;
        }
        a.delete-btn:hover {
            background-color: #c82333;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 7px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 6px;
            font-size: 1rem;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
            margin-bottom: 15px;
            box-sizing: border-box;
            transition: border-color 0.2s ease-in-out;
        }
        input[type="text"]:focus, textarea:focus {
            border-color: #007BFF;
            outline: none;
        }
        button[type="submit"] {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 1rem;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 700;
            transition: background-color 0.2s ease-in-out;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
        a.back-link {
            display: inline-block;
            margin-top: 30px;
            color: #007BFF;
            text-decoration: none;
            font-weight: 600;
        }
        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h1>Admin Panel</h1>

<h2>Comments</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Comment</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $result = $conn->query("SELECT * FROM comments ORDER BY created_at DESC");
        if ($result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
        <tr>
            <td><?= e($row['id']) ?></td>
            <td><?= e($row['username']) ?></td>
            <td><?= e($row['comment']) ?></td>
            <td><?= e($row['created_at']) ?></td>
            <td>
                <a href="admin.php?delete_comment=<?= e($row['id']) ?>" 
                   onclick="return confirm('Are you sure you want to delete this comment?')" 
                   class="delete-btn">Delete</a>
            </td>
        </tr>
        <?php
            endwhile;
        else:
        ?>
        <tr><td colspan="5">No comments found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<h3>Add a New Comment</h3>
<form method="POST" action="admin.php" novalidate>
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required maxlength="100" />

    <label for="comment">Comment:</label>
    <textarea id="comment" name="comment" rows="4" required maxlength="1000"></textarea>

    <button type="submit" name="submit_comment">Submit Comment</button>
</form>

<h2>Contact Messages</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $result = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC");
        if ($result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
        <tr>
            <td><?= e($row['id']) ?></td>
            <td><?= e($row['name']) ?></td>
            <td><?= e($row['email']) ?></td>
            <td><?= e($row['message']) ?></td>
            <td><?= e($row['created_at']) ?></td>
            <td>
                <a href="admin.php?delete_contact=<?= e($row['id']) ?>" 
                   onclick="return confirm('Are you sure you want to delete this message?')" 
                   class="delete-btn">Delete</a>
            </td>
        </tr>
        <?php
            endwhile;
        else:
        ?>
        <tr><td colspan="6">No messages found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<a href="attacks.html" class="back-link">← Back to Home</a>

</body>
</html>
