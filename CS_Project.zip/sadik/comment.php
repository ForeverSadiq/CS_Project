<?php
include 'db.php';

// Handle delete request (when "delete" link is clicked)
if (isset($_GET['delete_comment'])) {
    $id = intval($_GET['delete_comment']);
    $conn->query("DELETE FROM comments WHERE id = $id");
    header("Location: comment.php"); // Reload after deletion
    exit();
}

// Fetch all comments
$result = $conn->query("SELECT * FROM comments ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Comment Page</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f8f8f8;
      padding: 20px;
    }

    .xss-info {
      max-width: 700px;
      margin: 20px auto 40px auto;
      padding: 20px 25px;
      border-left: 6px solid #e74c3c;
      background-color: #fdecea;
      color: #c0392b;
      box-shadow: 0 2px 6px rgba(231, 76, 60, 0.2);
      border-radius: 5px;
      font-size: 16px;
    }

    .xss-info strong {
      font-size: 18px;
      display: block;
      margin-bottom: 8px;
    }

    .xss-info em {
      font-style: normal;
      color: #7f8c8d;
    }

    .xss-info .icon {
      display: inline-block;
      vertical-align: middle;
      margin-right: 10px;
      font-size: 24px;
    }

    .comment-form {
      max-width: 700px;
      margin: 0 auto 40px auto;
      background: #ffffff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .comment-form h1 {
      text-align: center;
      margin-bottom: 20px;
      color: #2c3e50;
    }

    .comment-form input[type="text"],
    .comment-form textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .comment-form button {
      padding: 10px 20px;
      background-color: #e74c3c;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .comment-form button:hover {
      background-color: #c0392b;
    }

    .comments-section {
      max-width: 700px;
      margin: 0 auto;
      background: #ffffff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .comments-section h2 {
      color: #444;
      border-bottom: 2px solid #eee;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }

    .comment-box {
      border-left: 4px solid #e74c3c;
      padding-left: 15px;
      margin-bottom: 20px;
    }

    .comment-box strong {
      color: #e74c3c;
      font-size: 16px;
    }

    .comment-box p {
      margin: 8px 0;
      color: #333;
    }

    .comment-box small {
      color: #777;
      font-size: 12px;
    }

    .comment-box a {
      text-decoration: none;
      color: red;
      font-size: 14px;
    }

    .comment-box a:hover {
      text-decoration: underline;
    }

    .back-link {
      display: block;
      text-align: center;
      margin-top: 40px;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <div class="xss-info">
    <span class="icon">⚠️</span>
    <strong>About XSS (Cross-Site Scripting) Attack:</strong>
    XSS is a security vulnerability that allows attackers to inject malicious scripts into web pages viewed by other users. These scripts can steal cookies, hijack sessions, or perform actions on behalf of the user. 
    In this <em>vulnerable</em> version, user inputs are not sanitized, so any JavaScript you enter will run immediately.
  </div>

  <div class="comment-form">
    <h1>📝 Leave a Comment</h1>
    <form action="save_comment.php" method="post">
      <input type="text" name="username" placeholder="Your Name" required>
      <textarea name="comment" placeholder="Your Comment" required></textarea>
      <button type="submit">Post Comment</button>
    </form>
  </div>

  <div class="comments-section">
    <h2>🗂️ Previous Comments</h2>
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<div class='comment-box'>";
            echo "<strong>" . $row['username'] . "</strong>";
            echo "<p>" . $row['comment'] . "</p>";  // ← intentionally not sanitized
            echo "<small>" . $row['created_at'] . "</small><br>";
            echo "<a href='comment.php?delete_comment=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this comment?\");'>🗑️ Remove</a>";
            echo "</div>";
        }
    } else {
        echo "<p>No comments yet.</p>";
    }
    ?>
  </div>

  <a href="attacks.html" class="back-link">← Back to Home</a>
</body>
</html>

