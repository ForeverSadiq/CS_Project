<?php
session_start();
include 'db.php';

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Target comment ID for deletion
$comment_id = 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>CSRF Protected Comment Deletion</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9fafb;
      color: #333;
      padding: 40px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      text-align: center;
    }
    h2 {
      font-weight: 700;
      margin-bottom: 20px;
      color: #2c3e50;
    }
    form {
      background: #fff;
      padding: 25px 30px;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 3px 7px rgba(0,0,0,0.1);
      max-width: 320px;
      width: 100%;
    }
    input[type="submit"] {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 6px;
      font-size: 1rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
      width: 100%;
    }
    input[type="submit"]:hover,
    input[type="submit"]:focus {
      background-color: #c0392b;
      outline: none;
    }
    a {
      margin-top: 30px;
      font-weight: 600;
      color: #2980b9;
      text-decoration: none;
      transition: color 0.3s ease;
    }
    a:hover,
    a:focus {
      color: #1c5980;
      outline: none;
    }
  </style>
</head>
<body>
  <h2>Delete Comment (CSRF Protected)</h2>
  <form method="POST" action="csrf_protected_delete.php" aria-label="Delete Comment Form">
    <input type="hidden" name="comment_id" value="<?php echo htmlspecialchars($comment_id); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
    <input type="submit" value="Delete Comment" aria-label="Submit Delete Comment">
  </form>
  <a href="attacks.html" aria-label="Back to Home">⬅ Back to Home</a>
</body>
</html>


