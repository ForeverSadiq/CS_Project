<?php
include 'logger.php';
$conn = mysqli_connect("localhost", "root", "", "testdb");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Log SQLi attempt if suspicious input is found
    if (preg_match("/('|--|#|\/\*|\*\/)/i", $username) || preg_match("/('|--|#|\/\*|\*\/)/i", $password)) {
        logAttack("SQL Injection", $_SERVER['REMOTE_ADDR'], "Username: $username, Password: $password");
    }

    // 🚨 Vulnerable query
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "❌ Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>SQL Injection Demo</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #fff9f9;
      padding: 20px;
    }

    h2 {
      text-align: center;
      color: #c0392b;
    }

    .sqli-info {
      max-width: 700px;
      margin: 20px auto 40px auto;
      padding: 20px 25px;
      border-left: 6px solid #e74c3c;
      background-color: #fdecea;
      color: #c0392b;
      box-shadow: 0 2px 6px rgba(231, 76, 60, 0.2);
      border-radius: 5px;
      font-size: 16px;
    }

    .sqli-info strong {
      font-size: 18px;
      display: block;
      margin-bottom: 8px;
    }

    .sqli-info em {
      font-style: normal;
      color: #7f8c8d;
    }

    .sqli-info .icon {
      display: inline-block;
      vertical-align: middle;
      margin-right: 10px;
      font-size: 24px;
    }

    .login-form {
      max-width: 500px;
      margin: 0 auto;
      padding: 25px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .login-form label {
      display: block;
      margin-bottom: 5px;
      color: #444;
    }

    .login-form input[type="text"],
    .login-form input[type="password"] {
      width: 100%;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
    }

    .login-form input[type="submit"] {
      padding: 10px 20px;
      background-color: #e74c3c;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .login-form input[type="submit"]:hover {
      background-color: #c0392b;
    }

    .error-message {
      color: #c0392b;
      text-align: center;
      margin-top: 15px;
    }

    .back-link {
      display: block;
      text-align: center;
      margin-top: 30px;
      font-weight: bold;
      color: #e74c3c;
    }

    .back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <h2>🚨 SQL Injection Demo (Vulnerable)</h2>

  <div class="sqli-info">
    <span class="icon">⚠️</span>
    <strong>About SQL Injection (SQLi) Attack:</strong>
    SQL Injection is a critical security vulnerability where attackers inject malicious SQL code through input fields. This can lead to unauthorized data access or modification. In this <em>vulnerable</em> version, user inputs are used directly in the SQL query without validation, making it prone to attacks.
  </div>

  <div class="login-form">
    <form method="POST" action="">
      <label for="username">Username:</label>
      <input type="text" name="username" id="username" required>

      <label for="password">Password: <span style="font-weight:normal; font-size: 13px;">(e.g. ' OR '1'='1)</span></label>
      <input type="password" name="password" id="password" required>

      <input type="submit" value="Login">
    </form>

    <?php if (isset($error)): ?>
      <div class="error-message"><?= $error ?></div>
    <?php endif; ?>
  </div>

  <a href="attacks.html" class="back-link">← Back to Home</a>

</body>
</html>
