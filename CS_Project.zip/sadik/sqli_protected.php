<?php
include 'logger.php';
$conn = mysqli_connect("localhost", "root", "", "testdb");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // ✅ Use prepared statement to prevent SQLi
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "❌ Invalid credentials.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>SQL Injection Demo - Protected</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f5fdf7;
      padding: 20px;
    }

    h2 {
      text-align: center;
      color: #2e7d32;
    }

    .sqli-info-protected {
      max-width: 700px;
      margin: 20px auto 40px auto;
      padding: 20px 25px;
      border-left: 6px solid #27ae60;
      background-color: #e6f4ea;
      color: #2e7d32;
      box-shadow: 0 2px 6px rgba(39, 174, 96, 0.2);
      border-radius: 5px;
      font-size: 16px;
    }

    .sqli-info-protected strong {
      font-size: 18px;
      display: block;
      margin-bottom: 8px;
    }

    .sqli-info-protected em {
      font-style: normal;
      color: #4caf50;
    }

    .sqli-info-protected .icon {
      display: inline-block;
      vertical-align: middle;
      margin-right: 10px;
      font-size: 24px;
    }

    .login-form {
      max-width: 500px;
      margin: 0 auto;
      padding: 25px;
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .login-form label {
      display: block;
      margin-bottom: 5px;
      color: #333;
    }

    .login-form input[type="text"],
    .login-form input[type="password"] {
      width: 100%;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
    }

    .login-form input[type="submit"] {
      padding: 10px 20px;
      background-color: #27ae60;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .login-form input[type="submit"]:hover {
      background-color: #1e8449;
    }

    .error-message {
      color: #c0392b;
      text-align: center;
      margin-top: 10px;
      font-weight: bold;
    }

    .back-link {
      display: block;
      text-align: center;
      margin-top: 30px;
      font-weight: bold;
      color: #27ae60;
    }

    .back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <h2>🛡️ SQL Injection Demo (Protected)</h2>

  <div class="sqli-info-protected">
    <span class="icon">✅</span>
    <strong>Protection Against SQL Injection:</strong>
    This version uses <em>prepared statements</em> and parameterized queries to safely handle user input and prevent malicious SQL code execution. This protects your application from SQL Injection attacks.
  </div>

  <div class="login-form">
    <form method="POST" action="">
      <label for="username">Username:</label>
      <input type="text" name="username" id="username" required>

      <label for="password">Password:</label>
      <input type="password" name="password" id="password" required>

      <input type="submit" value="Login">
    </form>

    <?php if (!empty($error)): ?>
      <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
  </div>

  <a href="attacks.html" class="back-link">← Back to Home</a>

</body>
</html>
