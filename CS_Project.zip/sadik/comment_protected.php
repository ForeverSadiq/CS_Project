<?php
include 'db.php';

// Handle delete request
if (isset($_GET['delete_comment'])) {
    $id = intval($_GET['delete_comment']);
    $conn->query("DELETE FROM comments WHERE id = $id");
    header("Location: comment_protected.php");
    exit();
}

// Fetch all comments
$result = $conn->query("SELECT * FROM comments ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Comment Page (Protected)</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5fdf7;
      padding: 20px;
    }

    .xss-info-protected {
      max-width: 700px;
      margin: 20px auto 40px auto;
      padding: 20px 25px;
      border-left: 6px solid #27ae60;
      background-color: #e6f4ea;
      color: #2e7d32;
      box-shadow: 0 2px 6px rgba(39, 174, 96, 0.2);
      border-radius: 5px;
      font-size: 16px;
    }

    .xss-info-protected strong {
      font-size: 18px;
      display: block;
      margin-bottom: 8px;
    }

    .xss-info-protected em {
      font-style: normal;
      color: #4caf50;
    }

    .xss-info-protected .icon {
      display: inline-block;
      vertical-align: middle;
      margin-right: 10px;
      font-size: 24px;
    }

    .comment-form {
      max-width: 700px;
      margin: 0 auto 40px auto;
      background: #ffffff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .comment-form h1 {
      text-align: center;
      margin-bottom: 20px;
      color: #2e7d32;
    }

    .comment-form input[type="text"],
    .comment-form textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .comment-form button {
      padding: 10px 20px;
      background-color: #27ae60;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .comment-form button:hover {
      background-color: #1e8449;
    }

    .comments-section {
      max-width: 700px;
      margin: 0 auto;
      background: #ffffff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .comments-section h2 {
      color: #2e7d32;
      border-bottom: 2px solid #eee;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }

    .comment-box {
      border-left: 4px solid #27ae60;
      padding-left: 15px;
      margin-bottom: 20px;
    }

    .comment-box strong {
      color: #27ae60;
      font-size: 16px;
    }

    .comment-box p {
      margin: 8px 0;
      color: #333;
    }

    .comment-box small {
      color: #777;
      font-size: 12px;
    }

    .comment-box a {
      text-decoration: none;
      color: green;
      font-size: 14px;
    }

    .comment-box a:hover {
      text-decoration: underline;
    }

    .back-link {
      display: block;
      text-align: center;
      margin-top: 40px;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <div class="xss-info-protected">
    <span class="icon">✅</span>
    <strong>XSS Protection Enabled:</strong>
    This version sanitizes and escapes all user inputs to prevent malicious scripts from executing. By encoding special characters, it effectively blocks Cross-Site Scripting attacks and keeps your site safe.
  </div>

  <div class="comment-form">
    <h1>🛡️ Leave a Comment (Protected)</h1>
    <form action="save_comment.php" method="post">
      <input type="text" name="username" placeholder="Your Name" required>
      <textarea name="comment" placeholder="Your Comment" required></textarea>
      <button type="submit">Post Comment</button>
    </form>
  </div>

  <div class="comments-section">
    <h2>📋 Previous Comments</h2>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='comment-box'>";
            echo "<strong>" . htmlspecialchars($row['username']) . "</strong>";
            echo "<p>" . nl2br(htmlspecialchars($row['comment'])) . "</p>";
            echo "<small>" . htmlspecialchars($row['created_at']) . "</small><br>";
            echo "<a href='comment_protected.php?delete_comment=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this comment?\");'>🗑️ Remove</a>";
            echo "</div>";
        }
    } else {
        echo "<p>No comments yet.</p>";
    }
    ?>
  </div>

  <a href="attacks.html" class="back-link">← Back to Home</a>
</body>
</html>
