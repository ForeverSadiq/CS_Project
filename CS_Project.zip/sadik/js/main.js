// Load existing comments when page loads
window.onload = function() {
    const savedComments = JSON.parse(localStorage.getItem('comments')) || [];
    const commentsList = document.getElementById('commentsList');
  
    savedComments.forEach(item => {
      const newComment = document.createElement('div');
      newComment.innerHTML = `<strong>${item.username}</strong>: ${item.comment}<hr>`;
      commentsList.appendChild(newComment);
    });
  };
  
  // Handle new comment submission
  document.getElementById('commentForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    const username = document.getElementById('username').value;
    const comment = document.getElementById('comment').value;
  
    const commentsList = document.getElementById('commentsList');
    const newComment = document.createElement('div');
    newComment.innerHTML = `<strong>${username}</strong>: ${comment}<hr>`;
    commentsList.appendChild(newComment);
  
    // Save to localStorage
    const savedComments = JSON.parse(localStorage.getItem('comments')) || [];
    savedComments.push({ username, comment });
    localStorage.setItem('comments', JSON.stringify(savedComments));
  
    document.getElementById('commentForm').reset();
  });
  