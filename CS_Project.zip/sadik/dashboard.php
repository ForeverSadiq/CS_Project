<?php
// No session check (deliberately vulnerable)
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <style>
    body {
      background-color: #111;
      color: #0f0;
      font-family: monospace;
      padding: 40px;
    }
    h1 {
      font-size: 36px;
    }
    .secret {
      margin-top: 30px;
      background-color: #222;
      padding: 20px;
      border-left: 5px solid red;
    }
    a {
      color: #00f;
    }
  </style>
</head>
<body>

  <h1>Welcome to Admin Dashboard</h1>
  <p><strong>Access Level:</strong> Full Admin Privileges</p>

  <div class="secret">
    <h2>⚠️ Confidential Data:</h2>
    <ul>
      <li>User Credentials: admin / 123456</li>
      <li>Payment Logs: (fake data)</li>
      <li>Server Access Token: abcd1234efgh5678</li>
    </ul>
  </div>

  <br><br>
  <a href="sqli_vulnerable.php">← Back to Login</a>

</body>
</html>
