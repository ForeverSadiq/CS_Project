<?php
function logAttack($type, $ip, $input) {
    $log = "[" . date("Y-m-d H:i:s") . "] [$type] [$ip] Input: $input\n";
    file_put_contents(__DIR__ . "/logs/attack_log.txt", $log, FILE_APPEND);
}
?>
